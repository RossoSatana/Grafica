package Entities;

import java.util.ArrayList;

public class User {
	private String id, pw;
	private ArrayList <Monster> team;
	
	public User(String id, String pw){
		this.id = id;
		this.pw = pw;
		
		team = new ArrayList();
	}

	public String getId() {
		return id;
	}

	public String getPw() {
		return pw;
	}

	public void setId(String id){
		this.id =id;
	}
	
	public void setPw(String pw){
		this.pw =pw;
	}
	
	public void addToTeam(Monster m){
		this.team.add(m);
	}
}
