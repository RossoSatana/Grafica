package Entities;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureAtlas.TextureAtlasData.Region;

public class Monster {
	private String denomination, clas , type, name, status;
	private int hp, mp, def, mDef, ad, ap;
	private int cHp, cMp, cDef, cMDef, cAd, cAp;
	private Texture image;
	private Region region;
	private int lvl, experience;
	private int position, codM;
	
	public Monster(String denomination, String clas, String type, int hp, int mp, int ad, int ap, int def, int mDef, int codM){
		this.denomination = denomination;
		this.clas = clas;
		this.type = type;
		this.hp = hp;
		this.mp = mp;
		this.ad = ad;
		this.ap = ap;
		this.def = def;
		this.mDef = mDef;
		this.codM = codM;
		image = new Texture(Gdx.files.internal("img/" + denomination + ".png"));
		lvl = 1;
		experience = 0;
	}

	public int getcHp() {
		return cHp;
	}

	public void setcHp(int cHp) {
		this.cHp = cHp;
	}

	public int getcMp() {
		return cMp;
	}

	public void setcMp(int cMp) {
		this.cMp = cMp;
	}

	public int getcDef() {
		return cDef;
	}

	public void setcDef(int cDef) {
		this.cDef = cDef;
	}

	public int getcMDef() {
		return cMDef;
	}

	public void setcMDef(int cMDef) {
		this.cMDef = cMDef;
	}

	public int getcAd() {
		return cAd;
	}

	public void setcAd(int cAd) {
		this.cAd = cAd;
	}

	public int getcAp() {
		return cAp;
	}

	public void setcAp(int cAp) {
		this.cAp = cAp;
	}

	public int getLvl() {
		return lvl;
	}

	public void setLvl(int lvl) {
		this.lvl = lvl;
	}

	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPosition() {
		return position;
	}

	public void setPosition(int position) {
		this.position = position;
	}
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}